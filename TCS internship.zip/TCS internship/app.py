# import necessary libraries
import numpy as np
from flask import Flask,request,render_template
import pickle

# load the pickled file 
model = pickle.load(open('lgb_model.pkl','rb'))

# create an object app taking current module as argument
app = Flask(__name__)

#decorator to route to main page
@app.route("/")
def home():
    return render_template('index.html')#returns the home page
    
# decorator to route to prediction page    
@app.route("/predict", methods=['POST'])
def predict():
    age = float(request.form['age'])
    workclass = float(request.form['workclass'])
    education = float(request.form['education'])
    marital_status = float(request.form['marital-status'])
    occupation = float(request.form['occupation'])
    relationship = float(request.form['relationship'])
    race = float(request.form['race'])
    sex = float(request.form['sex'])
    hours_per_week = float(request.form['hours-per-week'])
    native_country = float(request.form['native-country'])

    arr = np.array([[age, workclass, education, marital_status, occupation, relationship, race, sex, hours_per_week, native_country]])
    prediction = model.predict(arr)
    if prediction == 0:
           result = '<=50K'
    elif prediction == 1:
           result = '>50K'
    
    
    #returns home page with the prediction
    return render_template('index.html', prediction_text='The predicted salary of employee is {}!'.format(result))

# to run 
if __name__ == "__main__":
    app.run(debug = True)


